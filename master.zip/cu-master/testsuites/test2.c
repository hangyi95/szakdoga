#include <stdio.h>
#include "../cu.h"

TEST(testTest2Function)
{
    assertTrue(1);
    assertFalse(0);
    printf("testTest2Function\n");
}

